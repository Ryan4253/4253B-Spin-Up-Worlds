Resources
=========

The following resources were referenced during the writing of Squiggles:

- `Team 254's contributions to WPILib <https://github.com/wpilibsuite/allwpilib>`_
- `Jaci Brunning's Pathfinder Library <https://github.com/JaciBrunning/Pathfinder>`_
- `Atsushi Sakai's Python Robotics <https://github.com/AtsushiSakai/PythonRobotics>`_