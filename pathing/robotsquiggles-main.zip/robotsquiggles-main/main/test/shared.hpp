#ifndef _TST_SHARED_HPP_
#define _TST_SHARED_HPP_

#define TEST_EPSILON (0.1)

#endif
